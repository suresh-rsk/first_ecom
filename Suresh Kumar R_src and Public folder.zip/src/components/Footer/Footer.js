import './Footer.css'



const Footer=()=>{

    return(
        <div>
        <div className="footer">
            
            
            


        </div>
        <div className="bottom">
            <p>&copy; Copyright Sureshkumar R</p>
            
        </div>
        </div>


    )
}

export default Footer;