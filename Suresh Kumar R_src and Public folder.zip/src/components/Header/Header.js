import './Header.css'

const Header = ()=>{
    return(
        <div>
            <div className="title"><h1>
                E Commerce Website
            </h1></div>
            
        </div>
    )
}

export default Header;