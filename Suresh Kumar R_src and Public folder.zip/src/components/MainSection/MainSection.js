

const MainSection =()=>{

    return(
        <div className="mainsection">Hhghjhjbhjkj</div> 
    )


}
 
export default MainSection();